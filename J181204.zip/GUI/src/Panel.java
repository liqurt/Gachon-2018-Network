import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Panel extends JFrame implements ActionListener {
   static JFrame f = new JFrame("Indian Poker");
   JTextField textField = new JTextField(25);
   JTextArea messageArea = new JTextArea(8, 25);
   BufferedReader in;
    PrintWriter out;
    SpinnerModel value;
    int remainchip=50;
    int e_chip=50;
    JSpinner spinner = new JSpinner();
    JTextArea txtrMyRemainChip = new JTextArea();
    TimerThread3 th;
    int chip;
    int mybet = 0;
    int e_bet = 0;
    int mycard;
    int e_card;
    int drawcount;
   int cumulativeChip=0;
   String userName;
   ArrayList deck;
   boolean giveUpState;
   int playState=0;
   String id;
   
    public Panel() throws IOException {
      Color back = new Color(70,0,21); // 배경색
      
      JFrame.setDefaultLookAndFeelDecorated(true);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      f.setSize(850,600);
      f.setResizable(false);
      JPanel jp1 = new JPanel();
      JPanel jp2 = new JPanel();
      
      // 패널 위, 아래 두개로 나눔 (jp1, jp2)
      f.getContentPane().setLayout(new BoxLayout(f.getContentPane(), BoxLayout.Y_AXIS));
      jp1.setLayout(new BorderLayout());
      jp2.setLayout(new BorderLayout());
   
      
      // 위 패널
      JLabel Card1 = new JLabel("", SwingConstants.CENTER);
      Card1.setToolTipText("");
      Card1.setIcon(new ImageIcon("뒷장.PNG"));
      Card1.setOpaque(true);
      Card1.setBackground(back);
      Card1.setPreferredSize(new Dimension(250, 400));
      
      JLabel Card2 = new JLabel("", JLabel.CENTER);
      Card2.setIcon(new ImageIcon("2.PNG"));
      Card2.setOpaque(true);
      Card2.setBackground(back);
      Card2.setPreferredSize(new Dimension(250, 400));
      
      JLabel Chip = new JLabel("", JLabel.CENTER);
      Chip.setIcon(new ImageIcon("칩.PNG"));
      Chip.setOpaque(true);
      Chip.setBackground(back);
      
      // 위 패널 배치
      jp1.add(Card2, BorderLayout.EAST);
      jp1.add(Card1, BorderLayout.WEST);
      jp1.add(Chip, BorderLayout.CENTER);
      
      
      // 아래 패널
      JLabel Betting = new JLabel("Betting, Give up", JLabel.CENTER);
      Betting.setOpaque(true);
      Betting.setBackground(back);
      Betting.setPreferredSize(new Dimension(250, 200));
       
      JLabel Chatting = new JLabel("Chatting", JLabel.CENTER);
      Chatting.setOpaque(true);
      Chatting.setBackground(back);
      
      JLabel Timer = new JLabel("Timer", JLabel.CENTER);
        
        getContentPane().setLayout(null);
        th=new TimerThread3(Timer);
        Timer.setBounds(400,330,150,50);
        Timer.setFont(new Font("Calibri", Font.BOLD, 50));
        //add(Timer);
        th.start();
        
        Timer.setOpaque(true);
        Timer.setBackground(back);
        Timer.setPreferredSize(new Dimension(250, 200));
        Timer.setForeground(Color.white);
       
      
      // 아래 패널 배치
      jp2.add(Timer,BorderLayout.EAST);
      jp2.add(Betting,BorderLayout.WEST);
      jp2.add(Chatting,BorderLayout.CENTER);
      
      
      // 채팅 레이아웃 설정
      Chatting.setLayout(new BorderLayout());
      textField.setForeground(Color.BLACK);
      
      textField.setEditable(false);
        messageArea.setForeground(Color.BLACK);
        messageArea.setEditable(false);
        
        // 채팅창 add
      Chatting.add(new JScrollPane(messageArea), BorderLayout.CENTER);
      Chatting.add(textField, BorderLayout.SOUTH);
      
      textField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                out.println(textField.getText());
                textField.setText("");
            }
        });
        
      
      // panel 나누기
      JPanel spinner_window = new JPanel();
      JPanel betting_button_window = new JPanel();
      JPanel button_window = new JPanel();
      button_window.setBounds(0, 0, 250, 92);
      Betting.setLayout(new BoxLayout(Betting, BoxLayout.Y_AXIS));
      
      // 베팅 spinner
    value = new SpinnerNumberModel(0, 0, 50, 1);
      spinner_window.setLayout(null);
      
      // 베팅 button
      JButton betting_button = new JButton("Betting");
      betting_button.setFont(new Font("Calibri", Font.PLAIN, 15));
      betting_button.setBounds(34, 12, 85, 33);
      betting_button.addActionListener(this);
      JButton giveup_button = new JButton("GiveUp");
      giveup_button.setFont(new Font("Calibri", Font.PLAIN, 15));
      giveup_button.setBounds(133, 12, 85, 33);
      giveup_button.addActionListener(this);
      
      betting_button_window.setLayout(null);
      
      button_window.setBackground(back);
      button_window.setLayout(null);
      button_window.add(betting_button);
      button_window.add(giveup_button);
      
      betting_button_window.add(button_window);
      Betting.add(spinner_window);
      
  
      spinner.setModel(value);
      spinner.setFont(new Font("Calibri", Font.PLAIN, 22));
      spinner.setBounds(70, 32, 114, 49);
      spinner_window.add(spinner);
   
     
     // String c=spinner.getValue();
      //STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL;
      
      JLabel Spinners = new JLabel("Spinners", JLabel.CENTER);
      Spinners.setBounds(0, 0, 250, 93);
      Spinners.setOpaque(true);
      Spinners.setBackground(back);
      Spinners.setPreferredSize(new Dimension(200, 400));
      spinner_window.add(Spinners);
      
      Betting.add(betting_button_window);
      
      f.getContentPane().add(jp1);
      
      JLabel title_label = new JLabel("Indian Poker", SwingConstants.CENTER);
      title_label.setFont(new Font("Calibri", Font.BOLD, 25));
      title_label.setBounds(335, 16, 164, 36);
      JPanel title = new JPanel();
      title.setBackground(back);
      title_label.setForeground(Color.white);
      title.setPreferredSize(new Dimension(850, 60));
      jp1.add(title, BorderLayout.NORTH);
      title.setLayout(null);
      title.add(title_label);
      //number of chip
    
      txtrMyRemainChip.setBackground(back);
      txtrMyRemainChip.setForeground(Color.WHITE);
      txtrMyRemainChip.setFont(new Font("바탕체", Font.BOLD, 14));
      txtrMyRemainChip.setEditable(false);
      txtrMyRemainChip.setWrapStyleWord(true);
      txtrMyRemainChip.setTabSize(1);
      txtrMyRemainChip.setLineWrap(true);
      txtrMyRemainChip.setText("     my remain chip : "+remainchip+"                                                     your remain chip : "+e_chip);
      jp1.add(txtrMyRemainChip, BorderLayout.SOUTH);
      f.getContentPane().add(jp2);

      JPanel panel = new JPanel();
      panel.setBackground(back);
      panel.setPreferredSize(new Dimension(850, 25));
      jp2.add(panel, BorderLayout.SOUTH);
      f.setVisible(true);
      
      run();
      
   }

   // 채팅 사용자 이름 입력
    public String getName() {
        return JOptionPane.showInputDialog(
            f, 
            "Choose a screen name:",
            "Screen name selection",
            JOptionPane.PLAIN_MESSAGE);
    }

      void run() throws IOException {
        Socket socket = new Socket("127.0.0.1", 9001);
        in = new BufferedReader(new InputStreamReader(
            socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        while (true) 
        {
            String line = in.readLine();
            if (line.startsWith("SUBMITNAME")) {
                out.println(getName());
            } else if (line.startsWith("NAMEACCEPTED")) {
                textField.setEditable(true);
            } else if (line.startsWith("MESSAGE")) {
                messageArea.append(line.substring(8) + "\n");
            }
            
            if(line.startsWith("play"))
            {   id=line;
               if(id.equals("play 1"))
               {  
            	   txtrMyRemainChip.repaint(); 
               txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 2 remain chip : "+e_chip);
               }
               else
               {  playState=1;
                  txtrMyRemainChip.repaint(); 
              txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 1 remain chip : "+e_chip);
               }
            
            }
            
            if(line.equals("0"))
               playState=0;
            
            if(line.startsWith("remainchip"))
            {
               
              if(id.equals("play 1"))
                {     String count[]=line.split(" ");//cut space
              e_chip=Integer.parseInt(count[1]);
              mycard = 4;
              e_card = 10;
                 txtrMyRemainChip.repaint(); 
           txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 2 remain chip : "+e_chip);
                }
              else
                {  
                 String count[]=line.split(" ");//cut space
                  e_chip=Integer.parseInt(count[1]);
                  mycard = 10;
                  e_card = 4;
                   txtrMyRemainChip.repaint(); 
               txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 1 remain chip : "+e_chip);
                    
                }
               
            }
            if(line.startsWith("betchip"))
            {
               
              if(id.equals("play 1"))
                {     String count[]=line.split(" ");//cut space
                	  e_bet=Integer.parseInt(count[1]);
                	  cumulativeChip += e_bet;
                }
              else
                {  
                 String count[]=line.split(" ");//cut space
                  e_bet=Integer.parseInt(count[1]);
                  cumulativeChip += e_bet;
                }
               
            }
           
           
        }
      }
      
    
   public static void main(String[] arguments) throws Exception {
      Panel p = new Panel();
      
   }
   
   @Override
   public void actionPerformed(ActionEvent e) {
      JButton b=(JButton)e.getSource();
   if(playState!=1)
      {if(th.n>0)
      {   if(b.getText().equals("Betting"))
      {
         int c=(int) spinner.getValue();
         if(remainchip-c<0)
         {
            txtrMyRemainChip.repaint(); 
            txtrMyRemainChip.setText(" 칩 부족!! 다시 베팅 하세요!"+"                                                     your remain chip : "+e_chip);
      
         /*   txtrMyRemainChip.repaint(); 
            txtrMyRemainChip.setText("     my remain chip : "+remainchip+"                                                     your remain chip : "+e_chip);*/
         }
         else if(c + mybet < e_bet)
         {
        	 txtrMyRemainChip.repaint(); 
             txtrMyRemainChip.setText(" 상대보다 적게 베팅할 수 없습니다"+"                                                     opponent's bet : "+e_bet);
         }
         else {  
            remainchip=remainchip-c;
            mybet += c;
            cumulativeChip += c;
            txtrMyRemainChip.repaint();
            if(id.equals("play 1"))
            	txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 2 remain chip : "+e_chip);
            else
            	txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 1 remain chip : "+e_chip);
         spinner.setValue(0);
         playState++;
         }
         
          if(mybet != 0 && e_bet != 0 && mybet == e_bet)
            {
            	if(mycard > e_card)
            	{
            		remainchip += cumulativeChip;
            		mybet = 0;
            		//e_bet = 0;
            		cumulativeChip = 0;
            	    txtrMyRemainChip.repaint(); 
                    txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 2 remain chip : "+e_chip);
                    out.println("SetResult "+id);
            		if(e_chip == 0)
            		{
            			out.println("Result "+id);
            		}
            		//else 카드 뽑기
            		
            	}
            	else if(mycard < e_card)
            	{
            		//e_chip += cumulativeChip;
            		mybet = 0;
            		//e_bet = 0;
            		cumulativeChip = 0;
            	    txtrMyRemainChip.repaint(); 
                    txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 1 remain chip : "+e_chip);
            		//카드 뽑기
            	
               }
            	/*else if(mycard == e_card)
            	{
            		drawcount++;
            		//카드 뽑기
            	}*/
          
         
      }
      
      
      }
      else if(b.getText().equals("GiveUp"))
      {
         spinner.setValue(0);
         if(mybet == 0) {
        	 remainchip--;
        	 e_chip += e_bet + 1;
         }
         else {
        	 remainchip -= mybet;
        	 e_chip += e_bet + mybet;
         }
         if(mycard == 10)
         {
        	 remainchip -= 10;
        	 e_chip += 10;
         }
         txtrMyRemainChip.repaint(); 
         txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 1 remain chip : "+e_chip);
         cumulativeChip = 0;
         mybet = 0;
         e_bet = 0;
         playState++;
      }
      else
      {
         txtrMyRemainChip.repaint(); 
         txtrMyRemainChip.setText("            시간 초과       "+"                                                     your remain chip : "+e_chip);
         spinner.setValue(0);
         playState++;
      }
      
     out.println("turnSwitch "+id+playState);//상대편으로 넘기는것
     out.println("e_remainchip "+id+" "+remainchip);//상대편으로 내 칩의 남은 개수를 넘겨 준다.
     out.println("e_betchip " +id+" "+mybet);

     
      }
   }
   }
   class TimerThread3 extends Thread {
      int n; 
       JLabel timerLabel; 
       boolean isRun = true; 
       
       public TimerThread3(JLabel timerLabel){ 
          this.timerLabel = timerLabel; 
       } 
   
       
       public void run() {
         
         if(playState==1)
         {
            
            isRun=false;
         }
         else {
            isRun=true;
            n = 90;
          while (n >= 0) {
             
             if(n < 10)
                timerLabel.setText("00:"+"0"+n);
             else
                timerLabel.setText("00:"+n);

             n--;
             timerLabel.repaint(); 
               
             try { 
                Thread.sleep(1000);
                       
                if (n == 100)
                   n = 0;
             } catch (InterruptedException e) { 
                      return; 
             }
               
             if(n==0)
             {     timerLabel.repaint(); 
                timerLabel.setText("TIME OVER");
             }
                 
          }
       }
       }
   
   }}
