import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Panel extends JFrame implements ActionListener {
	static int ID = 1;

	static int tc1;
	static int tc2;
	static boolean r1;
	static boolean r2;

	static JFrame f = new JFrame("Indian Poker");
	JTextField textField = new JTextField(25);
	JTextArea messageArea = new JTextArea(8, 25);
	BufferedReader in;
	PrintWriter out;
	SpinnerModel value;
	int remainchip=50;
	int e_chip=50;
	int cumul_chip=0;
	JSpinner spinner = new JSpinner();
	JTextArea txtrMyRemainChip = new JTextArea();
	TimerThread3 th;
	int playState=0;
	String id;

	public Panel(IndianPoker_user anUser) throws IOException {
		Color back = new Color(70,0,21); // ����

		JFrame.setDefaultLookAndFeelDecorated(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		f.setSize(850,600);
		f.setResizable(false);
		JPanel jp1 = new JPanel();
		JPanel jp2 = new JPanel();

		// �г� ��, �Ʒ� �ΰ��� ���� (jp1, jp2)
		f.getContentPane().setLayout(new BoxLayout(f.getContentPane(), BoxLayout.Y_AXIS));
		jp1.setLayout(new BorderLayout());
		jp2.setLayout(new BorderLayout());


		// �� �г�
		JLabel Card1 = new JLabel("", SwingConstants.CENTER);
		Card1.setToolTipText("");
		Card1.setIcon(new ImageIcon("����.PNG"));
		Card1.setOpaque(true);
		Card1.setBackground(back);
		Card1.setPreferredSize(new Dimension(250, 400));

		JLabel Card2 = new JLabel("", JLabel.CENTER);
		Card2.setIcon(new ImageIcon("2.PNG"));
		Card2.setOpaque(true);
		Card2.setBackground(back);
		Card2.setPreferredSize(new Dimension(250, 400));

		JLabel Chip = new JLabel("", JLabel.CENTER);
		Chip.setIcon(new ImageIcon("Ĩ.PNG"));
		Chip.setOpaque(true);
		Chip.setBackground(back);

		// �� �г� ��ġ
		jp1.add(Card2, BorderLayout.EAST);
		jp1.add(Card1, BorderLayout.WEST);
		jp1.add(Chip, BorderLayout.CENTER);


		// �Ʒ� �г�
		JLabel Betting = new JLabel("Betting, Give up", JLabel.CENTER);
		Betting.setOpaque(true);
		Betting.setBackground(back);
		Betting.setPreferredSize(new Dimension(250, 200));

		JLabel Chatting = new JLabel("Chatting", JLabel.CENTER);
		Chatting.setOpaque(true);
		Chatting.setBackground(back);

		JLabel Timer = new JLabel("Timer", JLabel.CENTER);

		getContentPane().setLayout(null);
		th=new TimerThread3(Timer);
		Timer.setBounds(400,330,150,50);
		Timer.setFont(new Font("Calibri", Font.BOLD, 50));
		//add(Timer);
		th.start();

		Timer.setOpaque(true);
		Timer.setBackground(back);
		Timer.setPreferredSize(new Dimension(250, 200));
		Timer.setForeground(Color.white);


		// �Ʒ� �г� ��ġ
		jp2.add(Timer,BorderLayout.EAST);
		jp2.add(Betting,BorderLayout.WEST);
		jp2.add(Chatting,BorderLayout.CENTER);


		// ä�� ���̾ƿ� ����
		Chatting.setLayout(new BorderLayout());
		textField.setForeground(Color.BLACK);
		textField.setEditable(false);
		messageArea.setForeground(Color.BLACK);
		messageArea.setEditable(false);

		// ä��â add
		Chatting.add(new JScrollPane(messageArea), BorderLayout.CENTER);
		Chatting.add(textField, BorderLayout.SOUTH);
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				out.println(textField.getText());
				textField.setText("");
			}
		});


		// panel ������
		JPanel spinner_window = new JPanel();
		JPanel betting_button_window = new JPanel();
		JPanel button_window = new JPanel();
		button_window.setBounds(0, 0, 250, 92);
		Betting.setLayout(new BoxLayout(Betting, BoxLayout.Y_AXIS));

		// ���� spinner
		value = new SpinnerNumberModel(0, 0, 50, 1);
		spinner_window.setLayout(null);

		// ���� button
		JButton betting_button = new JButton("Betting");
		betting_button.setFont(new Font("Calibri", Font.PLAIN, 15));
		betting_button.setBounds(34, 12, 85, 33);
		betting_button.addActionListener(this);
		JButton giveup_button = new JButton("GiveUp");
		giveup_button.setFont(new Font("Calibri", Font.PLAIN, 15));
		giveup_button.setBounds(133, 12, 85, 33);
		giveup_button.addActionListener(this);

		betting_button_window.setLayout(null);

		button_window.setBackground(back);
		button_window.setLayout(null);
		button_window.add(betting_button);
		button_window.add(giveup_button);

		betting_button_window.add(button_window);
		Betting.add(spinner_window);


		spinner.setModel(value);
		spinner.setFont(new Font("Calibri", Font.PLAIN, 22));
		spinner.setBounds(70, 32, 114, 49);
		spinner_window.add(spinner);


		// String c=spinner.getValue();
		//STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL;

		JLabel Spinners = new JLabel("Spinners", JLabel.CENTER);
		Spinners.setBounds(0, 0, 250, 93);
		Spinners.setOpaque(true);
		Spinners.setBackground(back);
		Spinners.setPreferredSize(new Dimension(200, 400));
		spinner_window.add(Spinners);

		Betting.add(betting_button_window);

		f.getContentPane().add(jp1);

		JLabel title_label = new JLabel("Indian Poker", SwingConstants.CENTER);
		title_label.setFont(new Font("Calibri", Font.BOLD, 25));
		title_label.setBounds(335, 16, 164, 36);
		JPanel title = new JPanel();
		title.setBackground(back);
		title_label.setForeground(Color.white);
		title.setPreferredSize(new Dimension(850, 60));
		jp1.add(title, BorderLayout.NORTH);
		title.setLayout(null);
		title.add(title_label);
		
		//number of chip

		txtrMyRemainChip.setBackground(back);
		txtrMyRemainChip.setForeground(Color.WHITE);
		txtrMyRemainChip.setFont(new Font("����ü", Font.BOLD, 14));
		txtrMyRemainChip.setEditable(false);
		txtrMyRemainChip.setWrapStyleWord(true);
		txtrMyRemainChip.setTabSize(1);
		txtrMyRemainChip.setLineWrap(true);
		txtrMyRemainChip.setText("     my remain chip : "+anUser.getChip()+"                                                     opponent's remain chip : "+e_chip);
		jp1.add(txtrMyRemainChip, BorderLayout.SOUTH);
		f.getContentPane().add(jp2);

		JPanel panel = new JPanel();
		panel.setBackground(back);
		panel.setPreferredSize(new Dimension(850, 25));
		jp2.add(panel, BorderLayout.SOUTH);
		f.setVisible(true);

		run(anUser);

	}

	// ä�� ����� �̸� �Է�
	public String getName(IndianPoker_user anUser) {
		String temp;
		temp = JOptionPane.showInputDialog(
				f, 
				"Choose a screen name:",
				"Screen name selection",
				JOptionPane.PLAIN_MESSAGE);
		anUser.setUserName(temp);
		System.out.println(temp);
		return temp;
	}

	void run(IndianPoker_user anUser) throws IOException {
		Socket socket = new Socket("127.0.0.1", 9001);
		in = new BufferedReader(new InputStreamReader(
				socket.getInputStream()));
		out = new PrintWriter(socket.getOutputStream(), true);

		while (true) 
		{
			String line = in.readLine();
			if (line.startsWith("SUBMITNAME")) {
				out.println(getName(anUser));
			} else if (line.startsWith("NAMEACCEPTED")) {
				textField.setEditable(true);
			} else if (line.startsWith("MESSAGE")) {
				messageArea.append(line.substring(8) + "\n");
			}

			if(line.startsWith("play"))
			{   
				id=line;
				if(id.equals("play 1"))
				{  
					id = anUser.getUserName();
					remainchip = anUser.getChip();
					anUser.setPlayerNumber(1);
					txtrMyRemainChip.repaint(); 
					txtrMyRemainChip.setText("    "+anUser.getUserName()+" remain chip : "+remainchip+"                                                   opponent's remain chip : "+e_chip);
				}
				else
				{  
					playState=1;
					id = anUser.getUserName();
					anUser.setPlayerNumber(2);
					remainchip = anUser.getChip();
					txtrMyRemainChip.repaint(); 
					txtrMyRemainChip.setText("    "+anUser.getUserName()+" remain chip : "+remainchip+"                                                   opponent's remain chip : "+e_chip);
				}
			}
			if(line.equals("0"))
				playState=0;
			if(line.startsWith("remainchip"))
			{
				if(id.equals("play 1"))
				{     
					String count[]=line.split(" ");//cut space
					e_chip=Integer.parseInt(count[1]);
					anUser.setPlayerNumber(1);
					txtrMyRemainChip.repaint(); 
					txtrMyRemainChip.setText("    "+anUser.getUserName()+" remain chip : "+remainchip+"                                                   opponent's remain chip : "+e_chip);
				}
				else
				{  
					String count[]=line.split(" ");//cut space
					e_chip=Integer.parseInt(count[1]);
					anUser.setPlayerNumber(2);
					txtrMyRemainChip.repaint(); 
					txtrMyRemainChip.setText("    "+anUser.getUserName()+" remain chip : "+remainchip+"                                                   opponent's remain chip : "+e_chip);
				}
			}


			int set=0;
			
			while(true) {
				//���� ī�带 ��������.
				if(((anUser.getUserName()).equals("A")) && (r1 == false)) {
					anUser.setPlayerNumber(1);
					System.out.println("�� ī��");
					tc1 = anUser.showCardInMyDeck(set);
					System.out.println(tc1);
					r1 = true;
				}else if(((anUser.getUserName()).equals("B")) && (r2 == false)) {
					anUser.setPlayerNumber(1);
					System.out.println("�� ī��");
					tc2 = anUser.showCardInMyDeck(set);
					System.out.println(tc2);
					r2 = true;				
				}
				
				//ready�� �����ֳ�
				//���� ���
				if((r1 == true) && (r2 == true)) {
					if(anUser.getPlayerNumber() == 1) {
						System.out.println("���� ī��");
						System.out.println(tc2);
					}else if(anUser.getPlayerNumber() == 2) {
						System.out.println("���� ī��");
						System.out.println(tc1);
					}
					break;
				}
				
			}
		}
	}

	public static void main(String[] arguments) throws Exception {
		IndianPoker_user anUser = new IndianPoker_user("SAMPLE",50,0,false,ID);
		ID++;
		Panel p = new Panel(anUser);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b=(JButton)e.getSource();
		if(playState!=1)
		{
			if(th.n>0)
			{   
				if(b.getText().equals("Betting"))
				{
					int c=(int) spinner.getValue();

					if(remainchip-c<0){
						txtrMyRemainChip.repaint(); 
						txtrMyRemainChip.setText(" Ĩ ����!! �ٽ� ���� �ϼ���!"+"                                                     your remain chip : "+e_chip);

						/*   txtrMyRemainChip.repaint(); 
            txtrMyRemainChip.setText("     my remain chip : "+remainchip+"                                                     your remain chip : "+e_chip);*/
					}
					else {  
						remainchip=remainchip-c;
						txtrMyRemainChip.repaint(); 
						txtrMyRemainChip.setText("    "+id+" remain chip : "+remainchip+"                                                   play 2 remain chip : "+e_chip);
						spinner.setValue(0);
						playState++;
						cumul_chip = cumul_chip + c;
						messageArea.setText("�� ����� ���ݲ� "+cumul_chip+" ���� Ĩ�� �����߽��ϴ�.");
					}
				}

				else if(b.getText().equals("GiveUp"))
				{
					spinner.setValue(0);
					playState++;
				}
			}
			else
			{
				txtrMyRemainChip.repaint(); 
				txtrMyRemainChip.setText("            �ð� �ʰ�       "+"                                                     your remain chip : "+e_chip);
				spinner.setValue(0);
				playState++;
			}

			out.println("turnSwitch "+id+playState);//��������� �ѱ�°�
			out.println("e_remainchip "+id+" "+remainchip);//��������� �� Ĩ�� ���� ������ �Ѱ� �ش�.
		}
	}

	class TimerThread3 extends Thread {
		int n; 
		JLabel timerLabel; 
		boolean isRun = true; 

		public TimerThread3(JLabel timerLabel){ 
			this.timerLabel = timerLabel; 
		} 


		public void run() {

			if(playState==1)
			{

				isRun=false;
			}
			else {
				isRun=true;
				n = 90;
				while (n >= 0) {

					if(n < 10)
						timerLabel.setText("00:"+"0"+n);
					else
						timerLabel.setText("00:"+n);

					n--;
					timerLabel.repaint(); 

					try { 
						Thread.sleep(1000);

						if (n == 100)
							n = 0;
					} catch (InterruptedException e) { 
						return; 
					}

					if(n==0)
					{     timerLabel.repaint(); 
					timerLabel.setText("TIME OVER");
					}

				}
			}
		}
	}
}