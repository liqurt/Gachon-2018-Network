
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class IndianPoker_user {

	int playerNumber;
	int chip;
	int cumulativeChip=0;
	String userName;
	ArrayList deck;
	boolean giveUpState;

	//constructor for debug
	public IndianPoker_user(String tempUserName, int tempChip, int tempCumulativeChip , boolean tempGiveUpState,int tempPlayerNumber) {
		this.userName = tempUserName;
		this.chip = tempChip;
		this.cumulativeChip = tempCumulativeChip;
		this.giveUpState = tempGiveUpState;
		this.deck = new ArrayList<>(10);
		for(int i =1 ; i<=10 ; i++) {
			this.deck.add(i);
		}
		Collections.shuffle(this.deck);
		try {
			Socket sock = new Socket("127.0.0.1",9001);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.playerNumber = tempPlayerNumber;
	}

	public int getChip() {
		return this.chip;
	}

	public int getCumulativeChip() {
		return this.cumulativeChip;
	}

	public String getUserName() {
		return this.userName;
	}
	
	public int getPlayerNumber() {
		return this.playerNumber;
	}

	//show whole deck list of course nobody use this.
	ArrayList getCardList() {
		return this.deck;
	}

	public int showCardInMyDeck(int set) {
		int yourCard =(int) this.deck.get(set);
		return yourCard;
	}

	public boolean getGiveUpState() {
		return this.giveUpState;
	}

	public int defaultBet() {
		this.chip = this.chip - 1;
		this.cumulativeChip = this.cumulativeChip + 1;
		return 1;
	}

	public int Betting() {
		System.out.println("�������ּ���");
		Scanner keyboard = new Scanner(System.in);
		int temp = keyboard.nextInt();
		return temp;
	}

	public void modifyChipsAndCumulativeChip(int betAmount) {
		this.chip = this.chip - betAmount;
		this.cumulativeChip = this.cumulativeChip + betAmount;
	}

	public void updateGiveUpState() {
		if(this.giveUpState == false) {
			this.giveUpState = true;
		}else if(this.giveUpState == true) {
			this.giveUpState = false;
		}
	}

	public void winnerTakesTotalBet(int totalBet) {
		this.chip = this.chip + totalBet;
	}

	public void giveUpWhen10Penalty() {
		this.chip = this.chip - 10;
	}

	public void giveUpWhen10Bonus() {
		this.chip = this.chip + 10;
	}

	public void initializeCumulativeChip() {
		this.cumulativeChip = 0;
	}

	public void initializeGiveUpState() {
		this.giveUpState = false;
	}
	
	public void setUserName(String temp) {
		this.userName = temp;
	}
	
	public void setPlayerNumber(int temp) {
		this.playerNumber = temp;
	}
}

