package indian;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.Random;

//import server.submit;

public class ChatServer {

   private static final int PORT = 9001;
   private static HashMap<String, PrintWriter>names=new HashMap<String, PrintWriter>();
   private static Socket play1Socket;
   private static Socket play2Socket;
   static int set = 0;
   static int p1_betchip = 0, p2_betchip = 0, temp = 0, current_bet = 0;
   static int p1_chip = 50, p2_chip = 50;
   static int betcnt = 0;
   //static int poker_set = 1;
   static int[] card1 = new int[10];
   static int[] card2 = new int[10];


   //���ν���
   
   public static void main(String[] args) throws Exception {
      Random random = new Random();
      for(int i = 0; i < 10; i++) {
         card1[i] = random.nextInt(10)+1;
      }

      for(int i = 0; i < 10; i++) {
         card2[i] = random.nextInt(10)+1;
      }

      int playId = 0;
      System.out.println("The chat server is running.");

      ServerSocket listener = new ServerSocket(PORT);
      try {
         while (true) {
            playId++;
            new Handler(listener.accept(),playId).start();
            System.out.println("The game is running. player "+playId);
         }
      } finally {
         listener.close();
      }

   }

   //���� ��
   
   private static class Handler extends Thread {
      
      PrintWriter out_1;
      PrintWriter out_2;
      
      private String name;
      private Socket socket;
      private BufferedReader in;
      private PrintWriter out;
      private int id;
      
      public Handler(Socket socket,int PlayId) throws IOException {
          
         this.socket = socket;
         this.id=PlayId;
         if(id==1)
            play1Socket = socket;
         else if(id==2) {
            play2Socket=socket;
         }
         
         
         broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
     
         
            if(id == 2) {
               out = new PrintWriter(play2Socket.getOutputStream(), true);
               out.println("CARDSET_YOUR" + ":" + card1[set]);
               out.println("SETSTATE:" + 0);
            }
            if(id == 1) {
               out = new PrintWriter(play1Socket.getOutputStream(), true);
               out.println("CARDSET_YOUR"+ ":" + card2[set]);
               out.println("SETSTATE:" + 1);
            }
          
         
      }

      public String getName(String name) 
      {
         return this.name;
      }

      public void run() {
         
         try {
            in = new BufferedReader(new InputStreamReader(
                  socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            while (true) {               
               out.println("SUBMITNAME");
               name = in.readLine();
               if (name == null) {
                  return;
               }

               synchronized (names) {
                  if (!names.containsKey(name)) {


                     for (PrintWriter writer : names.values()) 
                     {
                       
                     }

                     names.put(name,out);
                     break;
                  }
               }
            }
            
            out.println("setid:player "+id);
            out.println("NAMEACCEPTED");
            
            names.put(name, out);
            
            
            
            while (true) { // Ŭ���̾�Ʈ���� ���� String ó�� *********************************************************************************************          
               
               
               String input = in.readLine();
               if( input == null) {
                  return;
                 }
                 String[] tokens = input.split(":");
                 
                 if("message".equals(tokens[0])) {
                    broadcast(this.name + " : " + tokens[1]);
                 }
                 
                 
                 if("betnum".equals(tokens[0])) {
                    
                    if(id == 1) {
                      if(p2_betchip > (p1_betchip + Integer.parseInt(tokens[1])) || Integer.parseInt(tokens[1]) > p1_chip) {
                         out = new PrintWriter(play1Socket.getOutputStream(), true);
                            out.println("REBET:");
                            continue;
                            
                      }
                    }else if(id == 2) {
                       if(p1_betchip > (p2_betchip + Integer.parseInt(tokens[1])) || Integer.parseInt(tokens[1]) > p2_chip) {
                          out = new PrintWriter(play2Socket.getOutputStream(), true);
                            out.println("REBET:");
                            continue;
                            
                       }
                    }
                    
                    if(betcnt % 2 == 0) {
                       broadcast("SETNUM:" + (set + 1));
                       p1_betchip += Integer.parseInt(tokens[1]);
                       p1_chip -= Integer.parseInt(tokens[1]);
                       current_bet += p1_betchip;
                       
                       out = new PrintWriter(play2Socket.getOutputStream(), true);
                       out.println("UPDATE:" + p2_chip + ":" + p1_chip);
                       
                    
                       out = new PrintWriter(play1Socket.getOutputStream(), true);
                       out.println("UPDATE:" + p1_chip + ":" + p2_chip);
                       
                       //broadcast("UPDATE:" + p1_chip + ":" + p2_chip + "\n");
                       broadcast("CURRENT:" + current_bet);
                       //System.out.println("p1 : " + p1_betchip + " p2 : " + p2_betchip + "\n");
                       betcnt++;
                    }else if(betcnt % 2 == 1) {
                       broadcast("SETNUM:" + (set + 1));
                       p2_betchip += Integer.parseInt(tokens[1]);
                       p2_chip -= Integer.parseInt(tokens[1]);
                       current_bet += p2_betchip;
                       
                       out = new PrintWriter(play2Socket.getOutputStream(), true);
                       out.println("UPDATE:" + p2_chip + ":" + p1_chip);
                       
                    
                       out = new PrintWriter(play1Socket.getOutputStream(), true);
                       out.println("UPDATE:" + p1_chip + ":" + p2_chip);
                       
                       //broadcast("UPDATE:" + p1_chip + ":" + p2_chip + "\n");
                       broadcast("CURRENT:" + current_bet);
                       //System.out.println("p1 : " + p1_betchip + " p2 : " + p2_betchip + "\n");
                       betcnt++;
                    }
                       
                    broadcast("ALERT" + ":" + this.name + " bet " + tokens[1] + " chip\n");
                    broadcast("SWITCHTURN");
                    
                    if(p1_betchip == p2_betchip) {
                       
                             out = new PrintWriter(play2Socket.getOutputStream(), true);
                             out.println("CARDSET_MINE" + ":" + card2[set]);
                             
                          
                             out = new PrintWriter(play1Socket.getOutputStream(), true);
                             out.println("CARDSET_MINE"+ ":" + card1[set]);
                             
                          
                       
                      
                       
                       if(card1[set] > card2[set]) {
                          p1_chip += (p1_betchip + p2_betchip + temp);
                          
                          out = new PrintWriter(play2Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p2_chip + ":" + p1_chip);
                          
                       
                          out = new PrintWriter(play1Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p1_chip + ":" + p2_chip);
                          
                          //broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
                          broadcast("player1 WIN\n");
                          p1_betchip = 0; p2_betchip = 0; temp = 0; current_bet = 0;
                          broadcast("CURRENT:" + current_bet);
                          
                       }
                       if(card1[set] < card2[set]) {
                          p2_chip += (p1_betchip + p2_betchip + temp);
                          
                          out = new PrintWriter(play2Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p2_chip + ":" + p1_chip);
                          
                       
                          out = new PrintWriter(play1Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p1_chip + ":" + p2_chip);
                          
                          //broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
                          broadcast("player2 WIN\n");
                          p1_betchip = 0; p2_betchip = 0; temp = 0; current_bet = 0;
                          broadcast("CURRENT:" + current_bet);
                          
                       }
                       if(card1[set] == card2[set]) {
                          temp = p1_betchip + p2_betchip;
                          
                          out = new PrintWriter(play2Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p2_chip + ":" + p1_chip);
                          
                       
                          out = new PrintWriter(play1Socket.getOutputStream(), true);
                          out.println("UPDATE:" + p1_chip + ":" + p2_chip);
                          
                          //broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
                          broadcast("Draw");
                          p1_betchip = 0; p2_betchip = 0;
                          broadcast("CURRENT:" + current_bet);
                          
                          if(p1_chip  == 0 && p2_chip == 0)
                             p1_chip = 50; p2_chip = 50;
                          
                       }
                       set++;
                       if(p1_chip == 0 || p2_chip == 0)
                       {
                          if(p1_chip == 0)
                             broadcast("Finish : p2 WIN\n");
                          else if(p2_chip == 0)
                             broadcast("Finish : p1 WIN\n");
                          //else if (p1_chip == 0 && p2_chip == 0)
                          break;
                       }
                       if(set > 10) {
                          if(p1_chip > p2_chip)
                             broadcast("Finish : p1 WIN\n");
                          else if(p1_chip < p2_chip)
                             broadcast("Finish : p2 WIN\n");
                          else if(p1_chip == p2_chip)
                             broadcast("Finish : Draw\n");
                          
                          break;
                       }
                       
                       try {
                           Thread.sleep(5000);
                        }catch(InterruptedException e) {
                           System.out.println(e.getMessage());
                        }
                        
                        broadcast("clean");
                       
                      broadcast("SETNUM:" + (set + 1));
                      //broadcast("ROUND " + set + 1);
                      
                      
                              out = new PrintWriter(play2Socket.getOutputStream(), true);
                              out.println("CARDSET_YOUR" + ":" + card1[set]);
                              
                           
                              out = new PrintWriter(play1Socket.getOutputStream(), true);
                              out.println("CARDSET_YOUR"+ ":" + card2[set]);
                              
                              
                              broadcast("CARDSET_RESET:\n");
                              

                           
                      
                    }
                    
                 }
                 if("giveup".equals(tokens[0])) {
                    
                    broadcast("ALERT" + ":" + this.name + " giveup");
                    broadcast("SWITCHTURN");
                    
                    out = new PrintWriter(play2Socket.getOutputStream(), true);
                     out.println("CARDSET_MINE" + ":" + card2[set]);
                     
                  
                     out = new PrintWriter(play1Socket.getOutputStream(), true);
                     out.println("CARDSET_MINE"+ ":" + card1[set]);
                     
                  
               
               try {
                  Thread.sleep(5000);
               }catch(InterruptedException e) {
                  System.out.println(e.getMessage());
               }
               
                  if(id == 1) {
                     if(p1_betchip == 0) {
                        p2_chip += 1 + p2_betchip + temp; p1_chip -= 1;
                     }else {
                     p2_chip += (p1_betchip + p2_betchip + temp);
                     }
                     if(card1[set] == 10) {
                       p2_chip += 10; p1_chip -= 10;
                    }
                     
                     out = new PrintWriter(play2Socket.getOutputStream(), true);
                     out.println("UPDATE:" + p2_chip + ":" + p1_chip + "\n");
                     
                  
                     out = new PrintWriter(play1Socket.getOutputStream(), true);
                     out.println("UPDATE:" + p1_chip + ":" + p2_chip + "\n");
                     
                     //broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
                    p1_betchip = 0; p2_betchip = 0; temp = 0; current_bet = 0;
                    broadcast("CURRENT:" + current_bet);
                    
                  }else if(id == 2) {
                     if(p2_betchip == 0) {
                        p2_chip -= 1; p1_chip += 1 + p1_betchip + temp;   
                     }else {
                     p1_chip += (p1_betchip + p2_betchip + temp);
                     }
                     if(card2[set] == 10) {
                       p2_chip -= 10; p1_chip += 10;
                    }   
                     
                     out = new PrintWriter(play2Socket.getOutputStream(), true);
                     out.println("UPDATE:" + p2_chip + ":" + p1_chip + "\n");
                     
                  
                     out = new PrintWriter(play1Socket.getOutputStream(), true);
                     out.println("UPDATE:" + p1_chip + ":" + p2_chip + "\n");
                     
                     //broadcast("UPDATE:" + p1_chip + ":" + p2_chip);
                     p1_betchip = 0; p2_betchip = 0; temp = 0; current_bet = 0;
                     broadcast("CURRENT:" + current_bet);
                  }
                  
                  set++;
                  
                  broadcast("SETNUM:" + (set + 1));
                 //broadcast("ROUND " + set + 1);
                 
                 
                         out = new PrintWriter(play2Socket.getOutputStream(), true);
                         out.println("CARDSET_YOUR" + ":" + card1[set]);
                         
                      
                         out = new PrintWriter(play1Socket.getOutputStream(), true);
                         out.println("CARDSET_YOUR"+ ":" + card2[set]);
                         
                         
                         broadcast("CARDSET_RESET:\n");
                  
                 }
                 
               
            }

         } catch (IOException e) {
            System.out.println(e);
         } finally {
            if (name != null) {
               names.remove(name);
            }
            if (out != null) {
               names.remove(out);

               for (PrintWriter writer : names.values()) 
               {
                  writer.println("MESSAGE " + "<EXIT : "+name+">");
               }
            }

            try {
               socket.close();
            } catch (IOException e) {
            }
         }
      }
      
      private void broadcast(String data) {
          
           synchronized (names) {

             for(PrintWriter writer : names.values()) {

               writer.println(data);

               writer.flush();

             }

           }

         }
      

      


   }
}