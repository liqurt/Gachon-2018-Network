package indian;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.Component;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;

import java.awt.Color;
import javax.swing.SwingConstants;



import javax.swing.JTextArea;
import javax.swing.JSpinner;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.awt.Button;

import javax.sound.sampled.CompoundControl;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.ScrollPaneConstants;

public class client extends JFrame{
   
   BufferedReader in;
      PrintWriter out;
      SpinnerModel value;
      int mychip = 50, yourchip = 50, cumulativeChip = 0;
      
      int set, k = 1;
      String userName, id;
      boolean giveUpState;
      int playState, inputCard = 0, idx1 = 0, idx2 = 0, count_s = 0;
      int pv_bet = 0;
      
      static int[] card = new int[10];
      int[] c1 = new int[10];
      int[] card1 = new int[10];
      int[] card2 = new int[10];
      
      static JFrame f = new JFrame("Indian Poker");
      JTextField textField = new JTextField("");
      JLabel yourcard = new JLabel("");
      JLabel mycard = new JLabel("");
      JLabel p2_chip = new JLabel("50");
      JLabel p1_chip = new JLabel("50");
      JLabel batchip = new JLabel("0");
      JLabel txtrSet = new JLabel("Round 1");
      JScrollPane scrollPane = new JScrollPane((Component) null);
      JTextArea messageArea = new JTextArea(8, 25);
      JSpinner spinner = new JSpinner();
      Button Betting_bt = new Button("Betting");
      Button giveup_bt = new Button("GiveUp");
      private final JLabel turn_is = new JLabel("");
      
      
   public client() throws IOException {
      f.setSize(1051, 656);
       f.setResizable(false);
       f.getContentPane().setBackground(new Color(70, 0, 21));
      f.getContentPane().setLayout(null);
      
      
      
      yourcard.setIcon(new ImageIcon("src//0.png"));
      yourcard.setBounds(785, 72, 154, 215);
      f.getContentPane().add(yourcard);
      
      mycard.setIcon(new ImageIcon("src//0.png"));
      mycard.setBounds(97, 72, 154, 215);
      f.getContentPane().add(mycard);
      p1_chip.setFont(new Font("Calibri", Font.PLAIN, 50));
      p1_chip.setForeground(Color.WHITE);
      
      
      p1_chip.setBounds(840, 303, 78, 104);
      f.getContentPane().add(p1_chip);
      p2_chip.setForeground(Color.WHITE);
      p2_chip.setFont(new Font("Calibri", Font.PLAIN, 50));
      
      
      p2_chip.setBounds(148, 309, 78, 92);
      f.getContentPane().add(p2_chip);
      batchip.setFont(new Font("Calibri", Font.PLAIN, 30));
      batchip.setForeground(Color.WHITE);
      
      
      batchip.setBounds(739, 482, 200, 49);
      f.getContentPane().add(batchip);
      txtrSet.setForeground(Color.WHITE);
      txtrSet.setFont(new Font("Calibri", Font.PLAIN, 30));
      
      
      txtrSet.setBounds(739, 431, 241, 41);
      
      
      f.getContentPane().add(txtrSet);
      scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
      
      
      scrollPane.setBounds(382, 424, 312, 143);
      f.getContentPane().add(scrollPane);
      
      
      scrollPane.setViewportView(messageArea);
      messageArea.setForeground(Color.BLACK);
      messageArea.setEditable(false);
      
      textField.setEditable(false);
      textField.setBounds(382, 567, 312, 21);
      textField.setForeground(Color.BLACK);
      f.getContentPane().add(textField);
      
      
      spinner.setFont(new Font("Calibri", Font.PLAIN, 22));
      spinner.setBounds(119, 449, 114, 49);
      f.getContentPane().add(spinner);
      Betting_bt.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            
            if(playState == 0) {
                  messageArea.append("wait....\n"); 
               }
               if (playState == 1) {
              
                        int c = (int) spinner.getValue();
                        
                        if(c <= 0)
                           messageArea.append("you can`t bet this number\n");
                        else
                        out.println("betnum:" + c);
                        spinner.setValue(0);
               }
         }
      });
      
      
      Betting_bt.setBounds(58, 540, 90, 41);
      f.getContentPane().add(Betting_bt);
      giveup_bt.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            if(playState == 0) {
                  messageArea.append("wait....\n"); 
               }
               if (playState == 1) {           
                        
                        out.println("giveup:");
                         spinner.setValue(0);
                        
                
               }
         }
      });
      
      textField.addActionListener(new ActionListener() { //엔터 눌렀을 때
            public void actionPerformed(ActionEvent e) {
               out.println("message:" + textField.getText());
               textField.setText("");
            }
         });
      
      
      giveup_bt.setBounds(208, 540, 90, 41);
      f.getContentPane().add(giveup_bt);
      turn_is.setForeground(Color.WHITE);
      turn_is.setFont(new Font("Calibri", Font.PLAIN, 30));
      turn_is.setBounds(739, 541, 265, 49);
      
      f.getContentPane().add(turn_is);
      
      JLabel lblNewLabel = new JLabel("Indian Poker");
      lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 70));
      lblNewLabel.setForeground(Color.WHITE);
      lblNewLabel.setBounds(330, 42, 388, 111);
      f.getContentPane().add(lblNewLabel);
      
      f.setVisible(true);
      
      run();
      
   }

   
   
   public String getName() {
         return JOptionPane.showInputDialog(f, "Choose a screen name:", "Screen name selection",
               JOptionPane.PLAIN_MESSAGE);
      }

      void run() throws IOException {
         Socket socket = new Socket("127.0.0.1", 9001);
         in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
         out = new PrintWriter(socket.getOutputStream(), true);
         
         
         
         while (true) { //서버에서 받은 내용 처리*****************************************************************************************************************
            String line = in.readLine();
            
            String[] tokens = line.split(":");
            
            if (line.startsWith("SUBMITNAME")) {
               out.println(getName());
            } else if (line.startsWith("NAMEACCEPTED")) {
               textField.setEditable(true);
            } else if(line.startsWith("SWITCHTURN")){
               if(playState == 0) {
                  playState = 1;
                  //textArea.append("Your turn!\n");
                   turn_is.setText("Your turn!"); 
               }else if(playState == 1) {
                  playState = 0;
                  turn_is.setText(""); 
               }
            } else if(tokens[0].equals("ALERT")){
               messageArea.append(tokens[1]);
            }
            else if(tokens[0].equals("SETSTATE")) {
               playState = Integer.parseInt(tokens[1]);
               if(Integer.parseInt(tokens[1]) == 1)
               //textArea.append("Your turn!\n");
                  turn_is.setText("Your turn!"); 
               
            } else if(tokens[0].equals("UPDATE")) {
               mychip = Integer.parseInt(tokens[1]);
               yourchip = Integer.parseInt(tokens[2]);
               p1_chip.setText("" + yourchip );
               p2_chip.setText("" + mychip );
                        
               
            } else if(tokens[0].equals("SETNUM"))txtrSet.setText(" Round " + tokens[1]);
           
            else if(tokens[0].equals("CARDSET_YOUR")){
               yourcard.setIcon(new ImageIcon("src//" + tokens[1] + ".png"));
            }else if(tokens[0].equals("CARDSET_MINE")){
               mycard.setIcon(new ImageIcon("src//" + tokens[1] + ".png"));
            }else if(tokens[0].equals("CARDSET_RESET")){
               mycard.setIcon(new ImageIcon("src//0.png"));
            }else if(tokens[0].equals("CURRENT")){
               batchip.setText("current chip: " + tokens[1]);
            }else if(tokens[0].equals("REBET")){
               messageArea.append("Chips must be less than your remain chip or higher than opponent's bet chip.\n");
            }else if(line.startsWith("player2 WIN")){
               messageArea.append("player2 WIN");
            }else if(line.startsWith("player1 WIN")){
               messageArea.append("player1 WIN");
            }else if(line.startsWith("Draw")){
               messageArea.append("Draw");
            }else if(line.startsWith("clean")){
               messageArea.setText("");
            }else if(tokens[0].equals("setid")){
                f.setTitle("Indian Poker : " + tokens[1]);
             }
            
            else{
                  messageArea.append(line + "\n");
                  
               }

          
         }
      }

      public static void main(String[] arguments) throws Exception {
         new client();
      }
}